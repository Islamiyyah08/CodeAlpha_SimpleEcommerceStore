from django.urls import path
from .views import product_list, add_to_cart, view_cart, remove_from_cart, checkout, update_cart, register, user_login, user_logout, product_detail
from . import views

urlpatterns = [
    path('', product_list, name='product_list'),
    path('add/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('cart/', view_cart, name='view_cart'),
    path('remove/<int:product_id>/', remove_from_cart, name='remove_from_cart'),
    path('checkout/', checkout, name='checkout'),
    path('update/<int:product_id>/<str:action>/', update_cart, name='update_cart'),
    path('register/', register, name='register'),
    path('login/', user_login, name='login'),  
    path('logout/', user_logout, name='logout'),
    path('product/<int:product_id>/', product_detail, name='product_detail'),
    path('orders/', views.order_history, name='order_history'),
    path('orders/<int:order_id>/', views.order_detail, name='order_detail'),
]
