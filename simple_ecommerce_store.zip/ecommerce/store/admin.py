from django.contrib import admin
from .models import Product, Order, OrderItem

# Register your models here.
from .models import Product

admin.site.register(Product)
admin.site.register(Order)
admin.site.register(OrderItem)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'price')
    search_fields = ('name',)
    list_filter = ('price',)

admin.site.site_header = "Mini Store Admin"
admin.site.site_title = "Mini Store Dashboard"
admin.site.index_title = "Manage Your Store"


class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'total', 'is_paid', 'created_at')
    list_filter = ('is_paid', 'created_at')

class OrderItemAdmin(admin.ModelAdmin):
    list_display = ('order', 'product', 'quantity', 'price')