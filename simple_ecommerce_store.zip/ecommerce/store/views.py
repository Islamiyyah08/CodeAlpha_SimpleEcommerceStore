from django.shortcuts import render, redirect, get_object_or_404
from .models import Product
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from .models import Order, OrderItem

# Product list view
def product_list(request):
    products = Product.objects.all()
    cart =  request.session.get('cart', {})

    cart_count = sum(item['quantity'] for item in cart.values())

    return render(request, 'store/product_list.html', {
        'products': products,
        'cart_count': cart_count
    })

# Add to cart using session
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    cart = request.session.get('cart', {})
    product_id = str(product_id)

    if product_id in cart:
        cart[product_id]['quantity'] += 1
        messages.info(request, f"Increased {product.name} quantity.")
    else:
        cart[product_id] = {
            'name': product.name,
            'price': float(product.price),
            'quantity': 1
        }
        messages.success(request, f"Added {product.name} to cart.")

    request.session['cart'] = cart
    return redirect('product_list')



# View cart page
def view_cart(request):
    cart = request.session.get('cart', {})
    total = 0

    for item in cart.values():
        item['subtotal'] = item['price'] * item['quantity']
        total += item['subtotal']

    return render(request, 'store/cart.html', {
        'cart': cart,
        'total': total
    })

# Remove item from cart
def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})
    product_id = str(product_id)

    if product_id in cart:
        product_name = cart[product_id]['name']
        cart.pop(product_id)
        messages.warning(request, f"Removed {product_name} from cart.")

    request.session['cart'] = cart
    return redirect('view_cart')

# Checkout view
@require_http_methods(["GET", "POST"])
@login_required
def checkout(request):
    cart = request.session.get('cart', {})

    if not cart:
        messages.warning(request, "Your cart is empty.")
        return redirect('product_list')

    cart_items = []
    total = 0

    for product_id, item in cart.items():
        subtotal = item['price'] * item['quantity']
        total += subtotal

        cart_items.append({
            'name': item['name'],
            'price': item['price'],
            'quantity': item['quantity'],
            'subtotal': subtotal
        })

    if request.method == "POST":
        order = Order.objects.create(
            user=request.user,
            total=total,
            is_paid=True
        )

        for product_id, item in cart.items():
            OrderItem.objects.create(
                order=order,
                product_name=item['name'],
                quantity=item['quantity'],
                price=item['price']
            )

        request.session['cart'] = {}
        messages.success(request, "Payment successful! Order placed.")
        return redirect('order_history')

    return render(request, 'store/checkout.html', {
        'cart_items': cart_items,
        'total': total
    })


def update_cart(request, product_id, action):
    cart = request.session.get('cart', {})

    product_id = str(product_id)

    if product_id in cart:
        product_name = cart[product_id]['name']

        if action == "add":
            cart[product_id]['quantity'] += 1
            messages.info(request, f"Increased {product_name} quantity.")

        elif action == "remove":
            cart[product_id]['quantity'] -= 1

            if cart[product_id]['quantity'] <= 0:
                cart.pop(product_id)
                messages.warning(request, f"Removed {product_name} from cart.")
            else:
                messages.info(request, f"Decreased {product_name} quantity.")
    
    request.session['cart'] = cart
    return redirect('view_cart')

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful.")
            return redirect('product_list')
    else:
        form = UserCreationForm()
    return render(request, 'store/register.html', {'form': form})

def user_login(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, "Login successful.")
            return redirect('product_list')
    else:
        form = AuthenticationForm()
    return render(request, 'store/login.html', {'form': form})

def user_logout(request):
    logout(request)
    messages.info(request, "Logged out successfully.")
    return redirect('product_list')

def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'store/product_detail.html', {'product': product})

@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'store/order_history.html', {
        'orders': orders
    })

def order_detail(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    return render(request, 'store/order_detail.html', {'order': order})